for i in range(9000,9100):
  for j in range(1,100):
    print("127.0.0." + str(j) + ":" + str(i))
